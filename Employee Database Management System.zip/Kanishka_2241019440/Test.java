package Kanishka_2241019440;
/*
 Name: Kanishka_Shrimali
 Sec_31
 B.tech(CSE)
 DSA_MinorProject
 */

import java.text.SimpleDateFormat;
import java.util.*;

class Employee {
    String name;
    int EmpID;
    double salary;
    String hire_date;
    String job_position;
    String contact_no;
    String address;

    void input(String name, int EmpID, double salary, String hire_date, String job_pos, String contact_no,
            String Address) {
        this.name = name;
        this.EmpID = EmpID;
        this.salary = salary;
        this.hire_date = hire_date;
        this.job_position = job_pos;
        this.contact_no = contact_no;
        this.address = Address;
    }

    void display() {
        System.out.println("Name:" + this.name + "\nEmp ID:" + this.EmpID + "\nsalary:" + this.salary + "\nHire date:"
                + this.hire_date);
        System.out.println(
                "\nJob position:" + this.job_position + "\nContact:" + this.contact_no + "\nAddress:" + this.address);
    }

    public String name() {
        return name;
    }

    public String hire_date() {
        return hire_date;
    }

    public String contact_no() {
        return contact_no;
    }

}

public class Test {
    public static void arrangeEmployeeBySalary(Employee e[]) {
        for (int i = 0; i < e.length; i++) {
            for (int j = 0; j < e.length; j++) {
                if (e[j].salary < e[i].salary) {
                    Employee temp = e[i];
                    e[i] = e[j];
                    e[j] = temp;
                }
            }
        }
        for (int i = 0; i < e.length; i++) {
            e[i].display();
        }
    }

    public static void getEmployeesByJobPosition(Employee e[], String jp) {
        for (int i = 0; i < e.length; i++) {
            if (e[i].job_position.equalsIgnoreCase(jp))
                e[i].display();
        }
    }

    public static void getEmployeesByHireDate(Employee e[], String d1, String d2) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        for (Employee employee : e) {
            String hireDateStr = employee.hire_date();
            try {
                Date hireDate = dateFormat.parse(hireDateStr);
                Date startDate = dateFormat.parse(d1);
                Date endDate = dateFormat.parse(d2);
                if (hireDate.after(startDate) && hireDate.before(endDate)) {
                    System.out.println("Name: " + employee.name() + ", Hire Date: " + hireDate);
                }
            } catch (Exception ex) {
                System.out.println("Invalid date format for employee " + employee.name());
            }
        }
    }

    public static int foreignEmployeeCount(Employee e[]) {
        int count = 0;
        for (Employee employee : e) {
            String countryCode = employee.contact_no().substring(0, 2);
            if (!countryCode.equals("91")) {
                count++;
            }
        }
        return count;
    }

    public static void getEmployeesBySalary(Employee e[], double s1, double s2) {
        for (int i = 0; i < e.length; i++) {
            if (e[i].salary >= s1 && e[i].salary <= s2) {
                e[i].display();
            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Employee a1[] = new Employee[2];
        for (int i = 0; i < a1.length; i++) {
            System.out.println("Enter the details of employee " + (i + 1) + " : ");
            a1[i] = new Employee();
            System.out.print("Name : ");
            String a = sc.nextLine();
            System.out.print("Employee ID : ");
            int b = sc.nextInt();
            System.out.print("Salary : ");
            double c = sc.nextDouble();
            sc.nextLine();
            System.out.print("Hire date : ");
            String d = sc.nextLine();
            System.out.print("Job position : ");
            String e = sc.nextLine();
            System.out.print("Contact no. : ");
            String f = sc.nextLine();
            System.out.println("Address : ");
            String g = sc.nextLine();
            a1[i].input(a, b, c, d, e, f, g);
        }

        System.out.println("Employees from highest paid to lowest:");
        arrangeEmployeeBySalary(a1);
        System.out.println("Employee with the manager post:");
        getEmployeesByJobPosition(a1, "Manager");
        System.out.println("Employees within the hire date 01-04-2022 to 31-03-2023:");
        getEmployeesByHireDate(a1, "01-04-2022", "31-03-2023");
        System.out.println("Foreign Employees:");
        int count = foreignEmployeeCount(a1);
        System.out.println("The number of foreign employee : " + count);
        System.out.println("Employees getting salary between 150000INR to 300000INR:");
        getEmployeesBySalary(a1, 150000, 300000);
    }
}



